<?php
	echo "PHP Sample ".$_POST["abc"]." + ".$_POST["def"]." = ".($_POST["abc"] + $_POST["def"]);
?>
